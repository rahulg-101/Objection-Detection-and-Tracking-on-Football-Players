# football-players-detection > 2024-05-08 5:24pm
https://universe.roboflow.com/roboflow-jvuqo/football-players-detection-3zvbc

Provided by a Roboflow user
License: CC BY 4.0

